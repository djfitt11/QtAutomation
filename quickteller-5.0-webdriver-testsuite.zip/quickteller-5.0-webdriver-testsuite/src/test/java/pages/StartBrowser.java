package pages;

import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StartBrowser {
	private WebDriver driver = null;
		
	public StartBrowser(WebDriver driver) {
		
		this.driver  = driver;
	}
	
	public WebDriver initializeBrowser() throws IOException {
			Properties config = new Properties(); 
			FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\java\\config\\config.properties");
			config.load(fis);
			String browserName = config.getProperty("browser");
			/*System.out.println("browserNAME=" + browserName);
			System.out.println("chrome".getClass().getName());*/
			if (browserName.equals("chrome")){
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();	
			this.driver = new ChromeDriver();
			}
			else if (browserName.equals("fireFox")) {
			
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
				
			this.driver = new FirefoxDriver();
			}
			else {
				WebDriverManager.iedriver().setup();
				driver = new InternetExplorerDriver();
			}
						
			System.out.println("Browser Initialize. Test Passed");
			return driver;

		}
		

	}

