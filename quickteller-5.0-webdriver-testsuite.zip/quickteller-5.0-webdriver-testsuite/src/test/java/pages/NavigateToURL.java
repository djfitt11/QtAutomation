package pages;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;

public class NavigateToURL {
		WebDriver driver;
		URL baseUrl = new URL();

		public NavigateToURL(WebDriver driver) {
			this.driver = driver;
		}
		public void launchURL() {
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			driver.get(baseUrl.qTBaseUrlUAT);
			driver.manage().window().maximize();
			//driver.manage().window().setSize(new Dimension(1366, 768));
						
			System.out.println("launchURL Test Passed");
		}

	}

