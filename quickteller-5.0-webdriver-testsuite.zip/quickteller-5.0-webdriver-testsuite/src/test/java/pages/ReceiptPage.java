package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ReceiptPage {

	private WebDriver driver = null;

	By successIcon = By.xpath("//section[@class='webpay__success__icon']//*[@id='Capa_1']");
	By successMeassage = By.xpath("//section[@class='receipt-status__message']");
	By amountOnReceiptPage = By.xpath("//p[contains(text(),'Amount')]");
	By surchargeOnReceiptPage = By.xpath("//p[contains(text(),'Surcharge')]");
	By transactionTypeOnReceiptPage = By.xpath("//p[contains(text(),'Transaction Type')]");
	By transactionReferenceOnReceiptPage = By.xpath("//p[contains(text(),'Transaction Reference')]");
	By transactionDateOnReceiptPage = By.xpath("//p[contains(text(),'Transaction Date')]");
	By payAnotherButton = By.xpath("//button[@id='payAnother']");
	By setUpAsRecurringButton = By.xpath("//button[@id='setAsRecurring']");
	By printReceiptOrDownloadReceiptButton = By.xpath("//div[@class='download-button']");
	By cancelButton = By.xpath("//body/section[@id='root']/div[@id='wrapper']/section/section/section/section[@class='active__payment']/section[@class='checkout']/div[@class='rodal rodal-fade-enter checkout__rodal']/div[@class='rodal-dialog rodal-slideLeft-enter']/section[@id='checkout']/section[@class='clearfix checkout__box']/div[@class='close__checkout']/span/*[1]");
	By transactionInProgressDisplayAlert = By.xpath("//section[@class='alert alert-warning']");
	By transactionInProgressInfoMessage = By.xpath("//h6[contains(text(),'Please check transaction history after 20mins to c')]");
	By transactionFailedDisplayAlert = By.xpath("//p[contains(text(),'Transaction Error')]");
	By errMsgTransactionErrFromRetryableFailureResponseCodes = By.xpath("//div[@class='toast toast-error']");

	public static void main(String[] args) {

	}

	public ReceiptPage(WebDriver driver){
		this.driver  = driver;
	}
	
	public void verifyErrMsgTransactionErrFromRetryableFailureResponseCodesIsPresent(){
		if( driver.findElement(errMsgTransactionErrFromRetryableFailureResponseCodes).isDisplayed())
		{
			System.out.println("errMsgTransactionErrFromRetryableFailureResponseCodes is Present");
		}else{
			System.out.println("errMsgTransactionErrFromRetryableFailureResponseCodes is Absent");
		}
	}
	
	public void verifyTransactionFailedDisplayAlertIsPresent(){
		if( driver.findElement(transactionFailedDisplayAlert).isDisplayed())
		{
			System.out.println("transactionFailedDisplayAlert is Present");
		}else{
			System.out.println("transactionFailedDisplayAlert is Absent");
		}
	}
	
	
	public void verifySuccessIconIsEnabled(){
		if( driver.findElement(successIcon).isEnabled())
		{	
			driver.quit();			
		}else{
			System.out.println("successIcon is Enabled");
		}
	}
	
	public void verifyTransactionInProgressInfoMessageIsPresent(){
		if( driver.findElement(transactionInProgressInfoMessage).isDisplayed())
		{
			System.out.println("transactionInProgressInfoMessage is Present");
		}else{
			System.out.println("transactionInProgressInfoMessage is Absent");
		}
	}
	
	public void verifyTransactionInProgressDisplayAlertIsPresent(){
		if( driver.findElement(transactionInProgressDisplayAlert).isDisplayed())
		{
			System.out.println("transactionInProgressDisplayAlert is Present");
		}else{
			System.out.println("transactionInProgressDisplayAlert is Absent");
		}
	}
	
	public void verifyCancelButtonIsPresent(){
		if( driver.findElement(cancelButton).isDisplayed())
		{
			System.out.println("cancelButton is Present");
		}else{
			System.out.println("cancelButton is Absent");
		}
	}
	public void clickOnCancelButton(){
		driver.findElement(cancelButton).click();
		System.out.println("cancelButton ClickOn Successfully");
	}
	
	public void verifyPrintReceiptOrDownloadReceiptButtonIsPresent(){
		if( driver.findElement(printReceiptOrDownloadReceiptButton).isDisplayed())
		{
			System.out.println("printReceiptOrDownloadReceiptButton is Present");
		}else{
			System.out.println("printReceiptOrDownloadReceiptButton is Absent");
		}
	}
	
	public void clickOnPrintReceiptOrDownloadReceiptButton(){
		driver.findElement(printReceiptOrDownloadReceiptButton).click();
		System.out.println("printReceiptOrDownloadReceiptButton ClickOn Successfully");
	}
	
	public void verifySetUpAsRecurringButtonIsPresent(){
		if( driver.findElement(setUpAsRecurringButton).isDisplayed())
		{
			System.out.println("setUpAsRecurringButton is Present");
		}else{
			System.out.println("setUpAsRecurringButton is Absent");
		}
	}
	
	public void clickOnSetUpAsRecurringButton(){
		driver.findElement(setUpAsRecurringButton).click();
		System.out.println("setUpAsRecurringButton ClickOn Successfully");
	}
	
	public void verifyPayAnotherButtonIsPresent(){
		if( driver.findElement(payAnotherButton).isDisplayed())
		{
			System.out.println("payAnotherButton is Present");
		}else{
			System.out.println("payAnotherButton is Absent");
		}
	}
	
	public void clickOnpayAnotherButton(){
		driver.findElement(payAnotherButton).click();
		System.out.println("payAnotherButton ClickOn Successfully");
	}
	
	
	public void verifyTransactionDateOnReceiptPageIsPresent(){
		if( driver.findElement(transactionDateOnReceiptPage).isDisplayed())
		{
			System.out.println("transactionDateOnReceiptPage is Present");
		}else{
			System.out.println("transactionDateOnReceiptPage is Absent");
		}
	}
	
	public void verifyTransactionReferenceOnReceiptPageIsPresent(){
		if( driver.findElement(transactionReferenceOnReceiptPage).isDisplayed())
		{
			System.out.println("transactionReferenceOnReceiptPage is Present");
		}else{
			System.out.println("transactionReferenceOnReceiptPage is Absent");
		}
	}
	
	public void verifyTransactionTypeOnSuccessReceiptPageIsPresent(){
		if( driver.findElement(transactionTypeOnReceiptPage).isDisplayed())
		{
			System.out.println("transactionTypeOnReceiptPage is Present");
		}else{
			System.out.println("transactionTypeOnReceiptPage is Absent");
		}
	}
	
	public void verifySurchargeOnReceiptPageIsPresent(){
		if( driver.findElement(surchargeOnReceiptPage).isDisplayed())
		{
			System.out.println("surchargeOnReceiptPage is Present");
		}else{
			System.out.println("surchargeOnReceiptPage is Absent");
		}
	}
	
	public void verifyAmountOnReceiptPage(){
		if( driver.findElement(amountOnReceiptPage).isDisplayed())
		{
			System.out.println("amountOnReceiptPage is Present");
		}else{
			System.out.println("amountOnReceiptPage is Absent");
		}
	}
	
	public void verifySuccessMeassageIsPresent(){
		if( driver.findElement(successMeassage).isDisplayed())
		{
			System.out.println("successMeassage is Present");
		}else{
			System.out.println("successMeassage is Absent");
		}
	}

	public void verifySuccessIconIsPresent(){
		if( driver.findElement(successIcon).isDisplayed())
		{
			System.out.println("SuccessIcon is Present");
		}else{
			System.out.println("SuccessIcon is Absent");
		}
	}
}

