package actions;

import org.testng.annotations.Test;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import methods.BuyAirtimeMtnEChargePrepaid;
import methods.BuyAirtimeVerveCardNoOTPIsRequired;
import methods.BuyAirtimeVerveCardNoOTPIsRequired100Naira;
import methods.BuyAirtimeVerveCardNoOTPIsRequired400Naira;
import methods.SuccessfulLogOut;
import pages.ReceiptPage;
import pages.StartBrowser;
import pages.URL;

public class ReceiptPageTestSuite {
	static WebDriver driver;
	URL baseUrl = new URL();

	@BeforeTest
	public void startUp() throws IOException {
		StartBrowser openConnection = new StartBrowser(driver);
		driver = openConnection.initializeBrowser();
	}
 
	@Test(priority = 1)
	public void verifyThatElementsOnSuccessReceiptPageArePresent() throws InterruptedException {

		BuyAirtimeVerveCardNoOTPIsRequired buyAirtimeVerveCard = new BuyAirtimeVerveCardNoOTPIsRequired(driver);
		buyAirtimeVerveCard.BuyAirtimeVerveCardNoOTPRequired();

		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//section[@class='webpay__success__icon']//*[@id='Capa_1']")));

		ReceiptPage testTo = new ReceiptPage(driver);
		testTo.verifyCancelButtonIsPresent();
		testTo.verifySuccessIconIsPresent();
		testTo.verifySuccessMeassageIsPresent();
		testTo.verifyAmountOnReceiptPage();
		testTo.verifySurchargeOnReceiptPageIsPresent();
		testTo.verifyTransactionTypeOnSuccessReceiptPageIsPresent();
		testTo.verifyTransactionReferenceOnReceiptPageIsPresent();
		testTo.verifyTransactionDateOnReceiptPageIsPresent();
		testTo.verifyPayAnotherButtonIsPresent();
		testTo.verifySetUpAsRecurringButtonIsPresent();
		testTo.verifyPrintReceiptOrDownloadReceiptButtonIsPresent();
		System.out.println("verifyElementsOnReceiptPage. Test Passed");

		SuccessfulLogOut logUserOut = new SuccessfulLogOut(driver);
		logUserOut.logOut();

	}

	@Test(priority = 2) 
	public void verifyThatElementsOnPendingSummaryPageArePresent() throws InterruptedException {
	  
	  BuyAirtimeMtnEChargePrepaid buyAirtimeVerveCard = new BuyAirtimeMtnEChargePrepaid(driver);
	  buyAirtimeVerveCard.BuyAirtimeVerveCardNoOTPRequired();
	  
	  WebDriverWait wait = new WebDriverWait(driver, 60);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.
	  xpath("//section[@class='alert alert-warning']")));
	  
	  ReceiptPage testTo = new ReceiptPage(driver);
	  testTo.verifyCancelButtonIsPresent();
	  testTo.verifyTransactionInProgressDisplayAlertIsPresent();
	  testTo.verifyAmountOnReceiptPage();
	  testTo.verifySurchargeOnReceiptPageIsPresent();
	  testTo.verifyTransactionReferenceOnReceiptPageIsPresent();
	  testTo.verifyTransactionDateOnReceiptPageIsPresent();
	  
	  System.out.println("verifyThatElementsOnPendingReceiptPageArePresent Test Passed");
	  
	  SuccessfulLogOut logUserOut = new SuccessfulLogOut(driver);
	  logUserOut.logOut();
	  
	  }
	  
	 @Test(priority = 3) 
	  public void verifyThatElementsOnFailureSummaryPageArePresent() throws InterruptedException {
	  
	  BuyAirtimeVerveCardNoOTPIsRequired400Naira buyAirtimeVerveCard = new BuyAirtimeVerveCardNoOTPIsRequired400Naira(driver);
	  buyAirtimeVerveCard.BuyAirtimeVerveCardNoOTPRequired();
	  
	  WebDriverWait wait = new WebDriverWait(driver, 60);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[contains(text(),'Transaction Error')]")));
	  
	  ReceiptPage testTo = new ReceiptPage(driver);
	  testTo.verifyTransactionFailedDisplayAlertIsPresent();
	  testTo.verifyAmountOnReceiptPage();
	  testTo.verifySurchargeOnReceiptPageIsPresent();
	  testTo.verifyTransactionReferenceOnReceiptPageIsPresent();
	  testTo.verifyTransactionDateOnReceiptPageIsPresent();
	  
	  System.out.println("verifyThatElementsOnFailureSummaryPageArePresent. Test Passed");
	  
	  SuccessfulLogOut logUserOut = new SuccessfulLogOut(driver);
	  logUserOut.logOut();
	  }
	  
	@Test(priority = 4) 
	  public void verifyThatUserRemainsOnPayPageWhenResponseCodeIsARetryableFailureResponseCodes() throws InterruptedException {
	  
	  BuyAirtimeVerveCardNoOTPIsRequired100Naira buyAirtimeVerveCard = new
	  BuyAirtimeVerveCardNoOTPIsRequired100Naira(driver);
	  buyAirtimeVerveCard.BuyAirtimeVerveCardNoOTPRequired();
	  
	  WebDriverWait wait = new WebDriverWait(driver, 60);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast toast-error']")));
	  
	  ReceiptPage testTo = new ReceiptPage(driver);
	  testTo.verifyErrMsgTransactionErrFromRetryableFailureResponseCodesIsPresent();
	  
	  System.out.println("verifyThatUserRemainsOnPayPageWhenResponseCodeIsARetryableFailureResponseCodes. Test Passed"); 
	  }

	@AfterTest
	public void tearDown() {
		driver.quit();
	}

}
