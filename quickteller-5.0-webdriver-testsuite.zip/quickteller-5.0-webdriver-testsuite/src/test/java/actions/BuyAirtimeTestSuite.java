package actions;
import org.testng.annotations.Test;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import pages.StartBrowser;

public class BuyAirtimeTestSuite {
	WebDriver driver = null;

	@BeforeTest
	public void startUp() throws IOException {
		StartBrowser openConnection = new StartBrowser(driver);
		driver = openConnection.initializeBrowser();
	}

	@Test(priority = 1)
	//Yet to be implemeted as the flow to get Otp from ESB and pass it here is still in progress
	public void buyAirtimeFlowEnterOTPAndMakePaymentSuccessfully() {
		
		}
	
	@Test(priority = 2)
	//Yet to be implemeted as the flow to get Otp from ESB and pass it here is still in progress
	public void buyAirtimeFlowCardDoesNotRequireOTPAndMakePaymentSuccessfully() {
		
		}

	@AfterTest
	public void tearDown() {

		driver.quit();
	}

}
