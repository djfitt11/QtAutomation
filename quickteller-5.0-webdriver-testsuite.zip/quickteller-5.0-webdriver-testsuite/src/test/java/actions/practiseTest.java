package actions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import methods.SuccessfulLogin;
import pages.BuyAirtimePage;
import pages.NavigateToURL;
import pages.QTHomePageScreen2;
import pages.StartBrowser;

public class practiseTest {
	
	WebDriver driver = null;

	@BeforeTest
	public void startUp() throws IOException {
		StartBrowser openConnection = new StartBrowser(driver);
		driver = openConnection.initializeBrowser();
	}

	@Test(priority = 1)
	//Yet to be implemeted as the flow to get Otp from ESB and pass it here is still in progress
	public void testDropDown() {
		
		NavigateToURL startWebsite = new NavigateToURL(driver);
		startWebsite.launchURL();
		
		QTHomePageScreen2 HomeScreenObjects = new QTHomePageScreen2(driver);
		HomeScreenObjects.clickOnBuyAirtimeIcon();
		
		BuyAirtimePage BuyAirtimePageObjects = new BuyAirtimePage(this.driver);
		BuyAirtimePageObjects.clickOnArrowNetworkFieldDropDownSelfRecharge();
		BuyAirtimePageObjects.selectAirtelRechargePinOptionFromDropDown();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Test passed");
		
		}
	
	@Test(priority = 2)
	//Yet to be implemeted as the flow to get Otp from ESB and pass it here is still in progress
	public void buyAirtimeFlowCardDoesNotRequireOTPAndMakePaymentSuccessfully() {
		
		}

	@AfterTest
	public void tearDown() {

		driver.quit();
	}


	
}
