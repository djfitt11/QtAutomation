package actions;

import org.testng.annotations.Test;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import pages.NavigateToURL;
import pages.QTHomePageScreen2;
import pages.StartBrowser;
import pages.URL;

public class HomeScreenTestSuite {
		static WebDriver driver;
		URL baseUrl = new URL();
		
		
		@BeforeTest
		public void startUp() throws IOException {
			StartBrowser openConnection = new StartBrowser(driver);
			driver = openConnection.initializeBrowser();
		}
	
		@Test
		public void verifyHomeScreenElementsPresent() {
			
			NavigateToURL startWebsite = new NavigateToURL(driver);
			startWebsite.launchURL();
		//	Set the screenSize you prefer	
		//	driver.manage().window().setSize(new Dimension(375, 667));
				System.out.println("screen-resolution set successfully");
				QTHomePageScreen2 HomeScreenObjects = new QTHomePageScreen2(driver);
				//HomeScreenObjects.verifySwitchToOldQuicktellerLinkIsPresent();
				//Link To Old quickteller has been removed.
				HomeScreenObjects.verifyQTLogoIsPresent();
				HomeScreenObjects.verifyPayPointLinkIsPresent();
				HomeScreenObjects.VerifyLoginButtonIsPresent();
				HomeScreenObjects.verifySignUpButtonIsPresent();
				HomeScreenObjects.VerifyDashboardIconIsPresent();
				HomeScreenObjects.VerifySend_ReceiveMoneyIconIsPresent();
				HomeScreenObjects.VerifyBuyAirtimeIconIsPresent();
				HomeScreenObjects.VerifyPayBillsIconIsPresent();
				HomeScreenObjects.verifyDashboardSearchFieldIsPresent();
				HomeScreenObjects.verifyHomePageWrapperIsPresent();
							
			System.out.println("verifyHomeScreenElementsPresent. Test Passed");
			
		}

		@AfterTest
		public void tearDown() {

			driver.quit();
		}

	}

