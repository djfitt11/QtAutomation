package actions;

import org.testng.annotations.Test;

import methods.SuccessfulLogin;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import pages.NavigateToURL;
import pages.QTHomePageScreen2;
import pages.SavedPaymentPage;
import pages.StartBrowser;
import pages.URL;

public class SavedPaymentSuite {
	static WebDriver driver = null;
	URL baseUrl = new URL();
	
	@BeforeTest
		public void startUp() throws IOException {
		StartBrowser openConnection = new StartBrowser(driver);
		driver = openConnection.initializeBrowser();
	}

	@Test(priority = 1)
	public void verifyQROptionIsPresentWhenPayingFromSavedPaymentAirtime() throws InterruptedException {
		NavigateToURL startWebsite = new NavigateToURL(driver);
		startWebsite.launchURL();
	
		SuccessfulLogin loginSuccessfully = new SuccessfulLogin(driver);
		loginSuccessfully.successfulLogin("dadubiaro@interswitch.com", "password");
		
		SavedPaymentPage  SavedPaymentObjects = new SavedPaymentPage(driver);
		SavedPaymentObjects.clickOnSavedPaymentsAirtimeIcon();
			Thread.sleep(2000);
			
		SavedPaymentObjects.clickOnfirstItemTabRecharge();
			Thread.sleep(2000);
			
		SavedPaymentObjects.clickOnPayButtonOnFirstItemInAirtelDataBundles();
			Thread.sleep(2000);
			
			WebDriverWait wait1 = new WebDriverWait(driver, 120);
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Card')]")));
				
		SavedPaymentObjects.VerifyCardElementIsPresent();
			Thread.sleep(2000);
	
		SavedPaymentObjects.VerifyQRCodeElementIsPresent();
		
		System.out.println("verifyQROptionIsPresentWhenPayingFromSavedPaymentAirtime Test Passed");
		}
	
	@Test(priority = 2)
	public void verifyQROptionIsPresentWhenPayingFromSavedPaymentForBills() throws InterruptedException {
		
		NavigateToURL startWebsite = new NavigateToURL(driver);
		startWebsite.launchURL();
		
		//SuccessfulLogin loginSuccessfully = new SuccessfulLogin(driver);
		// loginSuccessfully.successfulLogin("dadubiaro@interswitch.com", "password");
		 
		QTHomePageScreen2 iAgree = new QTHomePageScreen2(driver);
		iAgree.clickOnIAgreeCookiePolicy();
		
		SavedPaymentPage  SavedPaymentObjects = new SavedPaymentPage(driver);
		SavedPaymentObjects.clickOnSavedPaymentsBillIcon();
			Thread.sleep(2000);
	
		//SavedPaymentObjects.clickOnTheThirdItemTabBills();
		SavedPaymentObjects.clickOnChurchOfGodMission();
			Thread.sleep(2000);
		
		SavedPaymentObjects.clickOnTheFirstPayButtonUnderChurchOfGodMission();
			Thread.sleep(2000);
	
		WebDriverWait wait = new WebDriverWait(driver, 120);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Card')]")));
			
		SavedPaymentObjects.VerifyCardElementIsPresent();
			Thread.sleep(2000);
		
		SavedPaymentObjects.VerifyQRCodeElementIsPresent();
		
		System.out.println("verifyQROptionIsPresentWhenPayingFromSavedPaymentForBills Test Passed");
		}
	
	@Test(priority = 3)
	public void verifyQROptionIsPresentWhenPayingFromSavedPaymentForTransfer() throws InterruptedException {
		NavigateToURL startWebsite = new NavigateToURL(driver);
		startWebsite.launchURL();
	
	
		Thread.sleep(1000);
		SavedPaymentPage  SavedPaymentObjects = new SavedPaymentPage(driver);
		SavedPaymentObjects.clickOnSavedPaymentsTransferIcon();
			Thread.sleep(1000);

		SavedPaymentObjects.clickOnFirstItemTabTransfer();
			Thread.sleep(1000);

		SavedPaymentObjects.clickOnFirstPayButtonOnFirstItemTabTransfer();
			Thread.sleep(1000);
			
		SavedPaymentObjects.clearAmountFieldForTransfer();
			Thread.sleep(1000);
		
		SavedPaymentObjects.EnterAmountInEditAmountFieldTransfer("200");
			Thread.sleep(1000);
			
		SavedPaymentObjects.VerifyDescriptionFieldIsPresent();
			Thread.sleep(1000);

		SavedPaymentObjects.clickOnContinueButtonTransfer();
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'QR Code')]")));
				
		SavedPaymentObjects.VerifyQRCodeElementIsPresent();
		
		System.out.println("verifyQROptionIsPresentWhenPayingFromSavedPaymentForTransfer Test Passed");
		}

	@AfterTest
	public void tearDown() {

		driver.quit();
	}

}

