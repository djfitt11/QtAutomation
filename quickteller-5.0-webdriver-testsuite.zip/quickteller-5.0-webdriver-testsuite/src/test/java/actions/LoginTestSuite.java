package actions;

import org.testng.annotations.Test;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import pages.Dashboard;
import pages.NavigateToURL;
import pages.QTHomePageScreen2;
import pages.QtLoginPage2;
import pages.StartBrowser;
import pages.URL;

public class LoginTestSuite {
	static WebDriver driver = null;
	URL baseUrl = new URL();

	@BeforeTest
	public void startUp() throws IOException {
		StartBrowser openConnection = new StartBrowser(driver);
		driver = openConnection.initializeBrowser();
	}

	
	  @Test(priority = 1) public void InvalidUsernameAndValidPassword() throws
	  InterruptedException { NavigateToURL startWebsite = new
	  NavigateToURL(driver); startWebsite.launchURL();
	  
	  QTHomePageScreen2 HomeScreenObjects = new QTHomePageScreen2(driver);
	  HomeScreenObjects.clickOnLoginButton();
	  
	  QtLoginPage2 LoginScreenObjects = new QtLoginPage2(driver);
	  
	  LoginScreenObjects.EnterUserNameInUserNameField("fg@th.colllllm");
	  LoginScreenObjects.EnterPasswordInUserPasswordField("password");
	  LoginScreenObjects.ClickOnLoginButton();
	  LoginScreenObjects.VerifyInvalidEmailOrMobileNo_ErrMsg2Displays();
	  
	  System.out.println("Test Passed");
	  
	  }
	  
	  @Test(priority = 2) public void validEmailAndInvalidPassword() {
	  NavigateToURL startWebsite = new NavigateToURL(driver);
	  startWebsite.launchURL();
	  
	  QTHomePageScreen2 HomeScreenObjects = new QTHomePageScreen2(driver);
	  HomeScreenObjects.clickOnLoginButton();
	  
	  QtLoginPage2 LoginScreenObjects = new QtLoginPage2(driver);
	  LoginScreenObjects.EnterUserNameInUserNameField("fg@th.com");
	  LoginScreenObjects.EnterPasswordInUserPasswordField("passwrpppd");
	  LoginScreenObjects.ClickOnLoginButton();
	  LoginScreenObjects.VerifyInvalidPassword_ErrMsg2Displays();
	  
	  System.out.println("Test Passed");
	  
	  }
	 

	@Test(priority = 3)
	public void successfulLogin() throws InterruptedException {
		NavigateToURL startWebsite = new NavigateToURL(driver);
		startWebsite.launchURL();
		
		QTHomePageScreen2 HomeScreenObjects = new QTHomePageScreen2(driver); 
		
		HomeScreenObjects.clickOnLoginButton();
		
		QtLoginPage2 LoginScreenObjects = new QtLoginPage2(driver);
		LoginScreenObjects.EnterUserNameInUserNameField("dadubiaro@interswitch.com");
		LoginScreenObjects.EnterPasswordInUserPasswordField("password");
			Thread.sleep(5000);
	
		LoginScreenObjects.ClickOnLoginButton();
		
		QTHomePageScreen2 iAgree = new QTHomePageScreen2(driver);
		iAgree.clickOnIAgreeCookiePolicy();
		
		Dashboard DashboardObjects = new Dashboard(driver);
		DashboardObjects.VerifyRecurringAirtimeIconIsPresent();
		
		System.out.println("Login Successful. Test Passed");	
		
	}

	@AfterTest
	public void tearDown() {

		driver.quit();
	}

}
