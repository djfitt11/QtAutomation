package actions;
import org.testng.annotations.Test;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import methods.BuyAirtimeCardRequiresOTP;
import pages.OTPScreen;
import pages.StartBrowser;
import pages.URL;

public class OTPTestSuite {
		static WebDriver driver = null;
		URL baseUrl = new URL();

		@BeforeTest
		public void startUp() throws IOException {
			StartBrowser openConnection = new StartBrowser(driver);
			driver = openConnection.initializeBrowser();
		}
	
		
		@Test(priority = 1)
		public void verifyOTPScreenDisplays() throws InterruptedException {
			BuyAirtimeCardRequiresOTP buyAirtime = new BuyAirtimeCardRequiresOTP(driver);
			buyAirtime.BuyAirtime7499CardRequiresOTP();
			
			OTPScreen OTPObjects = new OTPScreen(driver);
			OTPObjects.VerifyOtpFieldIsPresent();
			OTPObjects.VerifyPayButtonOnOtpScreenIsPresent();
			OTPObjects.VerifyResendOtpLinkIsPresent();
			OTPObjects.VerifyThatTheEnterOtpSentMessageIsPresent();
						
			System.out.println("Test Passed");
		}
		
		@Test(priority = 2)
		public void InvalidOTPTest() {
			OTPScreen OTPObjects = new OTPScreen(driver);
			OTPObjects.EnterOtpInOtpField("1234");
			OTPObjects.clickOnPayButtonOnOtpScreen();
			OTPObjects.VerifyErrMsgInvalidOtpIsPresent();
			
			
			System.out.println("Test Passed");
		}
		
		@Test(priority = 3)
		public void doNotEnterOTPTest() {
			OTPScreen OTPObjects = new OTPScreen(driver);
			OTPObjects.clickOnPayButtonOnOtpScreen();
			OTPObjects.VerifyErrMsgNoOtpEnteredIsPresent();
						
			System.out.println("Test Passed");
		}
		
		@Test(priority = 4)
		public void ResendOtpTest() throws InterruptedException {
			OTPScreen OTPObjects = new OTPScreen(driver);
			Thread.sleep(3000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement resendOtpLink = driver.findElement(By.xpath("//section[contains(text(),'Resend OTP')]"));
			js.executeScript("arguments[0].scrollIntoView();", resendOtpLink);
			Thread.sleep(3000);
			OTPObjects.VerifyResendOtpLinkIsPresent();
			OTPObjects.clickOnResendOtpLink();
			Thread.sleep(3000);
			OTPObjects.VerifyOtpWasResentSuccessfullyMessageIsPresent();
			System.out.println("Test Passed");
		}
		
		@AfterTest
		public void tearDown() {

			driver.quit();
		}

	} 

