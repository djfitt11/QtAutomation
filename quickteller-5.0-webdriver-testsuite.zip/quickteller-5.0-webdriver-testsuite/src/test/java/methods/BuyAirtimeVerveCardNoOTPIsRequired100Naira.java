package methods;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.BuyAirtimePage;
import pages.Dashboard;
import pages.NavigateToURL;
import pages.PayPage;
import pages.QTHomePageScreen2;
import pages.Toggle;

//This will attempt to do a transaction for Airtel with N100, but will fail, because the Stock for 100 is finished in VTUCare
public class BuyAirtimeVerveCardNoOTPIsRequired100Naira {
	private WebDriver driver = null;
	
	public BuyAirtimeVerveCardNoOTPIsRequired100Naira(WebDriver driver) {
		this.driver  = driver;
	}
	
	public void BuyAirtimeVerveCardNoOTPRequired() throws InterruptedException {
		NavigateToURL startWebsite = new NavigateToURL(this.driver);
		startWebsite.launchURL();
		
		JavascriptExecutor js = (JavascriptExecutor) this.driver;
		
		SuccessfulLogin loginSuccessfully = new SuccessfulLogin(this.driver);
		loginSuccessfully.successfulLogin("dadubiaro@interswitch.com", "password");
		QTHomePageScreen2 HomeScreenObjects = new QTHomePageScreen2(this.driver);
			
		WebDriverWait wait = new WebDriverWait(this.driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Buy Airtime')]")));
		Dashboard DashboardObjects = new Dashboard(this.driver);
		DashboardObjects.VerifyRecurringAirtimeIconIsPresent();
		HomeScreenObjects.clickOnBuyAirtimeIcon();
		
		
		BuyAirtimePage BuyAirtimePageObjects = new BuyAirtimePage(this.driver);
			Thread.sleep(5000);
			
		WebElement ArrowDropDownToTopUpOtherNumbers = driver.findElement(By.xpath("//section[@id='rechageOthers']//span[@class='accordion__arrow']"));
		js.executeScript("arguments[0].scrollIntoView();", ArrowDropDownToTopUpOtherNumbers);
		
		BuyAirtimePageObjects.clickOnArrowToTopUpOthersDropDown();
			Thread.sleep(2000);
	
		BuyAirtimePageObjects.EnterMobileNumberInFieldInTopOtherNumbersSection("08124888436");
		BuyAirtimePageObjects.EnterAmountInRechargeOthersField("100");
		
		WebElement continueButton = driver.findElement(By.xpath("//span[contains(text(),'Continue')]"));
		js.executeScript("arguments[0].scrollIntoView();", continueButton);
		
		Toggle clickOnToggle = new Toggle(this.driver);
		clickOnToggle.clickOntoggleBackward();
		BuyAirtimePageObjects.clickOnContinueButtonRechargeOthersSection();
			Thread.sleep(3000);
	
			QTHomePageScreen2 iAgree = new QTHomePageScreen2(driver);
			iAgree.clickOnIAgreeCookiePolicy();
			
		PayPage PayPageObjects = new PayPage(this.driver);
		PayPageObjects.clickOnArrowWalletCardsDropDown2();
		PayPageObjects.selectVerveEcash6573Card();
		WebElement pinPad = driver.findElement(By.xpath("//div[contains(@class,'open__pinpad')]"));
		js.executeScript("arguments[0].scrollIntoView();", pinPad);
		PayPageObjects.EnterEcash6573Pin();
		/*WebElement pinPad = driver.findElement(By.xpath("//div[contains(@class,'open__pinpad')]"));
		js.executeScript("arguments[0].scrollIntoView();", pinPad);
		PayPageObjects.clickOnPinNumber1();
		PayPageObjects.clickOnPinNumber2();
		PayPageObjects.clickOnPinNumber3();
		PayPageObjects.clickOnPinNumber4();*/
		
		WebElement payButton = driver.findElement(By.xpath("//button[@id='webpayPay']"));
		js.executeScript("arguments[0].scrollIntoView();", payButton);
		PayPageObjects.VerifyPayButtonIsPresent();
		PayPageObjects.clickOnPayButton();
	
		System.out.println("BuyAirtimeVerveCardNoOTPIsRequired. Test Passed");
		}
	
}