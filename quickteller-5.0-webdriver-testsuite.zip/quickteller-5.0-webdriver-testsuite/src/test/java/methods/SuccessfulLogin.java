package methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pages.Dashboard;
import pages.QTHomePageScreen2;
import pages.QtLoginPage2;

public class SuccessfulLogin {
	private WebDriver driver = null;
	
	public SuccessfulLogin(WebDriver driver) {	
		this.driver  = driver;
	}
	
	public void successfulLogin(String username, String password) throws InterruptedException {
		
		QTHomePageScreen2 HomeScreenObjects = new QTHomePageScreen2(driver);
			Thread.sleep(3000);
			
		HomeScreenObjects.clickOnLoginButton();
		QtLoginPage2 LoginScreenObjects = new QtLoginPage2(driver);		
		
		//assertTrue(!isElementPresent(By.linkText("Empresas en Misi�n")));
		//boolean titleTextfield = driver.findElement(By.cssSelector("#accountLoginFormUsername")).isDisplayed();
		if(driver.findElements(By.cssSelector("#accountLoginFormUsername")).size() != 0){
			System.out.println("Element is Present");
			LoginScreenObjects.EnterUserNameInUserNameField(username);
			LoginScreenObjects.EnterPasswordInUserPasswordField(password);
				Thread.sleep(2000);
		
			LoginScreenObjects.ClickOnLoginButton();
			
			WebDriverWait wait = new WebDriverWait(this.driver, 60);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//body/section[@id='root']/div[@id='wrapper']/section/section/header[@id='topBarHeader']/section[@id='topBarHeaderAccount']/section[@id='account']/section[@id='dashboardContainer']/section[contains(@class,'')]/section[6]/section[1]/section[1]/section[2]/section[1]/section[1]")));
			
			Dashboard DashboardObjects = new Dashboard(driver);
			DashboardObjects.VerifyRecurringAirtimeIconIsPresent();
			}else{
			System.out.println("Element is Absent");
			LoginAsADifferentUser gotoLogin = new LoginAsADifferentUser(driver);
			gotoLogin.loginAsADifferentUser();
			LoginScreenObjects.EnterUserNameInUserNameField(username);
			LoginScreenObjects.EnterPasswordInUserPasswordField(password);
				Thread.sleep(2000);
		
			LoginScreenObjects.ClickOnLoginButton();
			
			Dashboard DashboardObjects = new Dashboard(driver);
			Thread.sleep(2000);
			DashboardObjects.VerifyRecurringAirtimeIconIsPresent();
			}
		
		System.out.println("Test Passed");
	}
}