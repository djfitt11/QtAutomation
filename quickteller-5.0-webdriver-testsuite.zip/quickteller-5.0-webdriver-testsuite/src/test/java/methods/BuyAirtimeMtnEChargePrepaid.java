package methods;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.BuyAirtimePage;
import pages.Dashboard;
import pages.NavigateToURL;
import pages.PayPage;
import pages.QTHomePageScreen2;
import pages.Toggle;


public class BuyAirtimeMtnEChargePrepaid {
	private WebDriver driver;
	
	public BuyAirtimeMtnEChargePrepaid(WebDriver driver) {
		this.driver  = driver;
	}
	
	public void BuyAirtimeVerveCardNoOTPRequired() throws InterruptedException {
		NavigateToURL startWebsite = new NavigateToURL(this.driver);
		startWebsite.launchURL();
		
		JavascriptExecutor js = (JavascriptExecutor) this.driver;

		SuccessfulLogin loginSuccessfully = new SuccessfulLogin(this.driver);
		loginSuccessfully.successfulLogin("dadubiaro@interswitch.com", "password");
		
		QTHomePageScreen2 HomeScreenObjects = new QTHomePageScreen2(this.driver);
			
		WebDriverWait wait = new WebDriverWait(this.driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Buy Airtime')]")));
		Dashboard DashboardObjects = new Dashboard(this.driver);
		DashboardObjects.VerifyRecurringAirtimeIconIsPresent();
		HomeScreenObjects.clickOnBuyAirtimeIcon();
		
		BuyAirtimePage BuyAirtimePageObjects = new BuyAirtimePage(this.driver);
			Thread.sleep(3000);
		WebElement ArrowDropDownToTopUpOtherNumbers = driver.findElement(By.xpath("//section[@id='rechageOthers']//span[@class='accordion__arrow']"));
		js.executeScript("arguments[0].scrollIntoView();", ArrowDropDownToTopUpOtherNumbers);
		
		BuyAirtimePageObjects.clickOnArrowToTopUpOthersDropDown();
			Thread.sleep(2000);
	
		BuyAirtimePageObjects.EnterMobileNumberInFieldInTopOtherNumbersSection("08131670272");
		BuyAirtimePageObjects.EnterAmountInRechargeOthersField("500");
		
		WebElement continueButton = driver.findElement(By.xpath("//span[contains(text(),'Continue')]"));
		js.executeScript("arguments[0].scrollIntoView();", continueButton);
		
		Toggle clickOnToggle = new Toggle(this.driver);
		clickOnToggle.clickOntoggleBackward();
		
		BuyAirtimePageObjects.clickOnContinueButtonRechargeOthersSection();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(@id, 'walletCards')]//*[contains(@class, 'Select-control')]//*[contains(@class, 'Select-input') and contains(@role, 'combobox')]")));
		
		PayPage PayPageObjects = new PayPage(this.driver);
		PayPageObjects.clickOnArrowWalletCardsDropDown2();
		WebElement pinPad = driver.findElement(By.xpath("//div[contains(@class,'open__pinpad')]"));
		js.executeScript("arguments[0].scrollIntoView();", pinPad);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(@class, 'Select-menu-outer')]//*[contains(@class, 'Select-menu')]//*[contains(@class, 'Select-option') and contains(@title, 'Verve eCash (**6573)')]")));
		PayPageObjects.selectVerveEcash6573Card();
		Thread.sleep(3000);
		PayPageObjects.EnterEcash6573Pin();
		/*WebElement pinPad = driver.findElement(By.xpath("//div[contains(@class,'open__pinpad')]"));
		js.executeScript("arguments[0].scrollIntoView();", pinPad);
		PayPageObjects.clickOnPinNumber1();
		PayPageObjects.clickOnPinNumber2();
		PayPageObjects.clickOnPinNumber3();
		PayPageObjects.clickOnPinNumber4();*/
		
		WebElement payButton = driver.findElement(By.xpath("//button[@id='webpayPay']"));
		js.executeScript("arguments[0].scrollIntoView();", payButton);
		PayPageObjects.VerifyPayButtonIsPresent();
		PayPageObjects.clickOnPayButton();
		
		
		System.out.println("BuyAirtimeVerveCardNoOTPIsRequired. Test Passed");
		}
	
}