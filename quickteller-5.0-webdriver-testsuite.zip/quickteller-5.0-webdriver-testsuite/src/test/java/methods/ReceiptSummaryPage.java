package methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import pages.NavigateToURL;
import pages.QTHomePageScreen2;
import pages.ReceiptPage;

public class ReceiptSummaryPage {

	private WebDriver driver = null;

	public static void main(String[] args) {

	}

	public ReceiptSummaryPage(WebDriver driver){
		this.driver  = driver;
	}

	public void verifyElementsOnSuccessReceiptPage(){

			ReceiptPage ReceiptPageObjects = new ReceiptPage(driver);
			ReceiptPageObjects.verifySuccessIconIsPresent();
			ReceiptPageObjects.verifySuccessMeassageIsPresent();
			ReceiptPageObjects.verifyAmountOnReceiptPage();
			ReceiptPageObjects.verifySurchargeOnReceiptPageIsPresent();
			ReceiptPageObjects.verifyTransactionTypeOnSuccessReceiptPageIsPresent();
			ReceiptPageObjects.verifyTransactionReferenceOnReceiptPageIsPresent();
			ReceiptPageObjects.verifyTransactionDateOnReceiptPageIsPresent();
			ReceiptPageObjects.verifyPayAnotherButtonIsPresent();
			ReceiptPageObjects.verifySetUpAsRecurringButtonIsPresent();
			ReceiptPageObjects.verifyPrintReceiptOrDownloadReceiptButtonIsPresent();
			ReceiptPageObjects.verifySuccessIconIsEnabled();
						
		System.out.println("verifyElementsOnSuccessReceiptPage. Test Passed");
	}
	
}
