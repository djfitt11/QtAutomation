package methods;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import pages.BuyAirtimePage;
import pages.Dashboard;
import pages.NavigateToURL;
import pages.PayPage;
import pages.QTHomePageScreen2;
import pages.QtLoginPage2;
import pages.Toggle;


public class BuyAirtimeVerveCardNoOTPIsRequired {
	private WebDriver driver = null;
	
	public BuyAirtimeVerveCardNoOTPIsRequired(WebDriver driver) {
		
		this.driver  = driver;
	}
	
	public void BuyAirtimeVerveCardNoOTPRequired() throws InterruptedException {
		NavigateToURL startWebsite = new NavigateToURL(this.driver);
		startWebsite.launchURL();
		
		JavascriptExecutor js = (JavascriptExecutor) this.driver;

		
		SuccessfulLogin loginSuccessfully = new SuccessfulLogin(this.driver);
		
		loginSuccessfully.successfulLogin("dadubiaro@interswitch.com", "password");	
		
		QTHomePageScreen2 HomeScreenObjects = new QTHomePageScreen2(this.driver);
			
		WebDriverWait wait = new WebDriverWait(this.driver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='sidebar__label'][contains(text(),'Buy Airtime')]")));
		Dashboard DashboardObjects = new Dashboard(this.driver);
		DashboardObjects.VerifyRecurringAirtimeIconIsPresent();
		HomeScreenObjects.clickOnBuyAirtimeIcon();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		BuyAirtimePage BuyAirtimePageObjects = new BuyAirtimePage(this.driver);
		WebElement dropDownArrow = driver.findElement(By.xpath("//section[@id='rechageOthers']//span[@class='accordion__arrow']"));
		js.executeScript("arguments[0].scrollIntoView();", dropDownArrow);
		
		BuyAirtimePageObjects.clickOnArrowToTopUpOthersDropDown();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BuyAirtimePageObjects.EnterMobileNumberInFieldInTopOtherNumbersSection("08124888436");
		BuyAirtimePageObjects.EnterAmountInRechargeOthersField("500");
		
		WebElement bottomOfPage = driver.findElement(By.xpath("//span[contains(text(),'Continue')]"));
		js.executeScript("arguments[0].scrollIntoView();", bottomOfPage);
		
		Toggle clickOnToggle = new Toggle(this.driver);
		clickOnToggle.clickOntoggleBackward();
		BuyAirtimePageObjects.clickOnContinueButtonRechargeOthersSection();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//section[@id='walletCards']//span[contains(@class,'Select-arrow-zone')]//span[contains(@class,'Select-arrow')]")));
		PayPage PayPageObjects = new PayPage(this.driver);
		PayPageObjects.clickOnArrowWalletCardsDropDown2();
		PayPageObjects.selectVerveEcash6573Card();
		WebElement payButton = driver.findElement(By.xpath("//button[@id='webpayPay']"));
		js.executeScript("arguments[0].scrollIntoView();", payButton);
		PayPageObjects.EnterEcash6573Pin();

		js.executeScript("arguments[0].scrollIntoView();", payButton);
		PayPageObjects.VerifyPayButtonIsPresent();
		PayPageObjects.clickOnPayButton();
		
		
		System.out.println("BuyAirtimeVerveCardNoOTPIsRequired. Test Passed");
		}
	
}