package methods;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import pages.PayPage;
import pages.StartBrowser;


public class CardPINs {

	private WebDriver driver;

	public static void main(String[] args) {

	}

	public CardPINs(WebDriver driver){
		this.driver  = driver;
	}
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	public void Ecash6573Pin()  {
		
		PayPage PayPageObjects = new PayPage(driver);
		WebElement pinPad = driver.findElement(By.xpath("//div[contains(@class,'open__pinpad')]"));
		js.executeScript("arguments[0].scrollIntoView();", pinPad);
		PayPageObjects.clickOnPinNumber1();
		PayPageObjects.clickOnPinNumber2();
		PayPageObjects.clickOnPinNumber3();
		PayPageObjects.clickOnPinNumber4();
		
		System.out.println("Ecash Pin Entered Successfully. Test Passed");
	}
	public void verveCard7499Pin(){
		PayPage PayPageObjects = new PayPage(driver);
		WebElement pinPad = driver.findElement(By.xpath("//div[contains(@class,'open__pinpad')]"));
		js.executeScript("arguments[0].scrollIntoView();", pinPad);
		PayPageObjects.clickOnPinNumber1();
		PayPageObjects.clickOnPinNumber1();
		PayPageObjects.clickOnPinNumber1();
		PayPageObjects.clickOnPinNumber1();
		
		System.out.println("7499 Pin Entered Successfully. Test Passed");
	}
}
