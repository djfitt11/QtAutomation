package methods;

import org.openqa.selenium.WebDriver;

import pages.QTHomePageScreen2;
import pages.QtLoginPage2;



public class LoginAsADifferentUser {
	private WebDriver driver = null;
	
	public LoginAsADifferentUser(WebDriver driver) {	
		this.driver  = driver;
	}
	
	public void loginAsADifferentUser() {
		
		QtLoginPage2 perform = new QtLoginPage2(driver);
		perform.ClickOnLoginAsADiffUser();
		perform.ClearUserNameInUserNameField();
		perform.ClearPasswordInPasswordField();
		
		System.out.println("LoginAsADifferentUser Test Passed");
	}
}