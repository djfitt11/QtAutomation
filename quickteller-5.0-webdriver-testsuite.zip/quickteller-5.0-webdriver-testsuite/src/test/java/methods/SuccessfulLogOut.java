package methods;

import org.openqa.selenium.WebDriver;

import pages.QTHomePageScreen2;
import pages.QtLoginPage2;
import pages.TopBarHeader;


public class SuccessfulLogOut {
	private WebDriver driver = null;
	
	public SuccessfulLogOut(WebDriver driver) {	
		this.driver  = driver;
	}
	
	public void logOut() {
		QTHomePageScreen2 gotoDashboard = new QTHomePageScreen2(driver);
		gotoDashboard.clickOnDashboardIcon();
		TopBarHeader successfulLogOut = new TopBarHeader(driver);
		successfulLogOut.clickOnProfileIcon();
		successfulLogOut.clickOnProfileDropdownSignOutLink3();
		
		QtLoginPage2 check = new QtLoginPage2(driver);
				
		System.out.println("SuccessfulLogOut Test Passed");
	}
}