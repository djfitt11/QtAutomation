package org.testng.annotations;

public class Before {

}
