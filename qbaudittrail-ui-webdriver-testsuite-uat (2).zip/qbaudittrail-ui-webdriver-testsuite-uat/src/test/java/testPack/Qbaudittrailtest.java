package testPack;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Qbaudittrailtest {
	
	static WebDriver driver;

		@BeforeMethod // Access to the URL
			public void setup() throws InterruptedException {
				
				//Set browser location
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\drivers\\chromedriver.exe");
				
				//launch a new browser
				driver = new ChromeDriver();
				
				//maximise launched browser
				driver.manage().window().maximize();
				
				//input URL
				driver.get("http://qb-ui-uat.k8.isw.la/");
				Thread.sleep(5000);
				
				//globally control the activity to keep running in case of connection issues
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
				
				//Click on the SIGNIN button from the Quick teller for Business page
				driver.findElement(By.xpath("/html//div[@id='root']//header/div/a[1]/span[@class='MuiButton-label']")).click();
				Thread.sleep(5000);
				
				//input user name, password and click on the login button to login
				driver.findElement(By.name("username")).sendKeys("amarachi@mailinator.com");
				driver.findElement(By.name("password")).sendKeys("password");
				driver.findElement(By.xpath("/html//div[@id='root']/div[2]/div/div[2]/div//form//button[@type='submit']/span[@class='MuiButton-label']")).click();
				//globally control the activity to keep running in case of connection issues
				Thread.sleep(5000);
				}
		
		@Test // Login successfully and view all audit trail for Test 1
		public void view_all_audit_trail() throws InterruptedException {
				
					//click on the Audit Trail menu
					driver.findElement(By.linkText("Audit Trail")).click();
					Thread.sleep(5000);
				};
		
		@Test // Filter audit trail by users for Test 2
		public void filter_audit_trail_by_valid_user() throws InterruptedException {
				
				//click on the Audit Trail menu
				driver.findElement(By.linkText("Audit Trail")).click();
				Thread.sleep(5000);
			
				//select the search field which is defaulted to ALL option
				driver.findElement(By.xpath("/html//div[@id='custom-input-searchterm']")).click();
				Thread.sleep(5000);
				
				//select the USER option from the drop-down list
				driver.findElement(By.xpath("//div[@id='menu-SearchTerm']//ul[@role='listbox']/li[2]")).click();
				Thread.sleep(5000);
				
				//click on the input name field and input the user's name
				driver.findElement(By.xpath("/html//div[@id='root']/div[@class='page_layout']/div[@class='main_root']/div/div/div[2]/div/div//form[@class='jss1108']//div[@role='combobox']//input")).sendKeys("amarachi@mailinator.com");
				Thread.sleep(50000);
				};
		@AfterMethod //Close Driver
	    public static void quitDriver() {
	    	// quit the browser activity after script runs
	        driver.quit();
	    }
}