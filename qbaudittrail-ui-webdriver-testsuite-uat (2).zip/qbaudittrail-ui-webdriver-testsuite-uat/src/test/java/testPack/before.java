package testPack;

public @interface before {

}
