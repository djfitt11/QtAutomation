package testPack;

public @interface test {

}
